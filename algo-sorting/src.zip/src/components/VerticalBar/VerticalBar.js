import React from "react";

import "./VerticalBar.css";

const verticalBar = (props) => {
    const { value } = props;
    return (
        <div className="Bar" style={{ height: `${value * 5}px` }}>
            &nbsp;
            {value}
        </div>
    );
};

export default verticalBar;
