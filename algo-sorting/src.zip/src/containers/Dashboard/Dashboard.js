import React, { Component } from "react";

import VerticalBar from "../../components/VerticalBar/VerticalBar";

import "./Dashboard.css";

class Dashboard extends Component {
    constructor(props) {
        super(props);

        this.state = {
            numbers: [],
            renderedVerticalBars: [],
            animations: [],
            indexAnim: 0,
        };
    }

    componentDidMount() {
        // this.generateNumbers();
    }

    insertionSort = () => {
        const animations = [];
        const numbers = [...this.state.numbers];
        console.log("numbers", numbers);
        console.log("...this.state.numbers", ...this.state.numbers);
        const len = numbers.length;

        for (let i = 1; i < len; i += 1) {
            const key = numbers[i];
            let j = i - 1;

            while (j >= 0 && numbers[j] > key) {
                const swap = {
                    num: numbers[j],
                    key,
                    a: j + 1,
                    b: j,
                };
                animations.push(swap);
                numbers[j + 1] = numbers[j];
                j -= 1;
            }
            numbers[j + 1] = key;
        }

        console.log(animations, numbers);
        this.setState({
            animations,
        });
    };

    generateNumbers = () => {
        const val = [];

        for (let i = 0; i <= 50; i += 1) {
            val.push(this.getRand(5, 100));
        }

        // val.push(1);
        // val.push(44);
        // val.push(52);
        // val.push(3);
        // val.push(8);

        console.log("preg", val);
        this.setState(
            {
                numbers: val,
            },
            () => this.generateBars()
        );
    };

    generateBars = () => {
        const { numbers } = this.state;
        let { renderedVerticalBars } = this.state;

        renderedVerticalBars = numbers.map((val, idx) => {
            return <VerticalBar key={idx} value={val} />;
        });

        console.log("gen", numbers);
        this.setState({
            renderedVerticalBars,
        });
    };

    getRand = (min, max) => {
        // https://stackoverflow.com/questions/1527803/generating-random-whole-numbers-in-javascript-in-a-specific-range
        return Math.floor(Math.random() * (max - min) + min);
    };

    delay = (ms) => new Promise((res) => setTimeout(res, ms));

    step = async () => {
        const { animations } = this.state;
        const { indexAnim, numbers } = this.state;

        for (let i = 0; i < animations.length; i += 1) {
            await this.delay(10);
            const { a, b, key } = animations[i];

            console.log("b", numbers[b]);
            console.log("a", numbers[a]);
            console.log("num", numbers);
            numbers[a] = numbers[b];
            numbers[b] = key;
            console.log(animations[indexAnim]);
            this.generateBars();
        }
    };

    render() {
        return (
            <>
                <div className="container">
                    <button onClick={this.generateNumbers}>Generate</button>
                    <button onClick={this.insertionSort}>insertionSort</button>
                    <button onClick={this.step}>step</button>
                </div>
                <div
                    className="container fixed-bottom"
                    style={{ marginBottom: "100px" }}
                >
                    <div className="d-flex flex-row align-items-end justify-content-center">
                        {this.state.renderedVerticalBars}
                    </div>
                </div>
            </>
        );
    }
}

export default Dashboard;
/**
 *  <div className="d-flex flex-row align-items-end mt-auto">
                        {this.state.renderedVerticalBars}
                    </div>
 */
